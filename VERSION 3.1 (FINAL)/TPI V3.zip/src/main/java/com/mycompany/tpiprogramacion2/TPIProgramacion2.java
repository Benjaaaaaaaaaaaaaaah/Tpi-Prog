package com.mycompany.tpiprogramacion2;

import com.mycompany.tpiprogramacion2.controlador.Controlador;

public class TPIProgramacion2 {

    public static void main(String[] args) {
        Controlador controlador = new Controlador();
        controlador.ejecutar();
    }
}
